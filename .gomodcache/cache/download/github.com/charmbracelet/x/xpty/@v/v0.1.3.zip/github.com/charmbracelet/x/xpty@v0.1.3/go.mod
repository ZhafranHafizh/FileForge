module github.com/charmbracelet/x/xpty

go 1.24.0

require (
	github.com/charmbracelet/x/conpty v0.1.1
	github.com/charmbracelet/x/term v0.2.1
	github.com/charmbracelet/x/termios v0.1.1
	github.com/creack/pty v1.1.24
	golang.org/x/sys v0.36.0
)

require github.com/charmbracelet/x/errors v0.0.0-20240508181413-e8d8b6e2de86 // indirect
