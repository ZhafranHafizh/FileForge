module charm.land/lipgloss/v2

retract v2.0.0-beta1 // We add a "." after the "beta" in the version number.

go 1.25.0

require (
	github.com/aymanbagabas/go-udiff v0.4.1
	github.com/charmbracelet/colorprofile v0.4.2
	github.com/charmbracelet/ultraviolet v0.0.0-20251205161215-1948445e3318
	github.com/charmbracelet/x/ansi v0.11.6
	github.com/charmbracelet/x/exp/golden v0.0.0-20250806222409-83e3a29d542f
	github.com/charmbracelet/x/term v0.2.2
	github.com/clipperhouse/displaywidth v0.11.0
	github.com/lucasb-eyer/go-colorful v1.3.0
	github.com/rivo/uniseg v0.4.7
	golang.org/x/sys v0.42.0
)

require (
	github.com/charmbracelet/x/termios v0.1.1 // indirect
	github.com/charmbracelet/x/windows v0.2.2 // indirect
	github.com/clipperhouse/uax29/v2 v2.7.0 // indirect
	github.com/mattn/go-runewidth v0.0.19 // indirect
	github.com/muesli/cancelreader v0.2.2 // indirect
	github.com/xo/terminfo v0.0.0-20220910002029-abceb7e1c41e // indirect
	golang.org/x/exp v0.0.0-20231006140011-7918f672742d // indirect
	golang.org/x/sync v0.18.0 // indirect
)
